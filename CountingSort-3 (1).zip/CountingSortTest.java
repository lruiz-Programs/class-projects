import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CountingSortTest {

	 @Test
	    void testCountingSortPositiveIntegers() {
	        int[] arr = {4, 2, 2, 8, 3, 3, 1};
	        int[] expected = {1, 2, 2, 3, 3, 4, 8};
	        CountingSort.sort(arr);
	        assertArrayEquals(expected, arr);
	    }
}
