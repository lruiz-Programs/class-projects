import java.util.Arrays;

/**
 * Leighana Ruiz 
 * I pledge my Honor that I have abided by the Stevens Honor System. 
 */
public class CountingSort {
	public static void sort(int[] A) {
        int arrayLength = A.length;
        int maxValue = 0;

        for (int i = 0; i < arrayLength; i++) {
        	maxValue = Math.max(maxValue, A[i]);
        }

        int[] countArray = new int[maxValue + 1];

        for (int i = 0; i < arrayLength; i++) {
            countArray[A[i]]++;
        }
        for (int i = 1; i <= maxValue ; i++) {
            countArray[i] += countArray[i - 1];
        }

        int[] outputArray = new int[arrayLength];

        for (int i = arrayLength - 1; i >= 0; i--) {
            outputArray[countArray[A[i]] - 1] = A[i];
            countArray[A[i]]--;
        }

        // Copying the sorted array back to the original array A
        for (int i = 0; i < arrayLength; i++) {
            A[i] = outputArray[i];
        }
    }
}

