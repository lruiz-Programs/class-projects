package rolodex;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import org.junit.jupiter.api.Assertions;


class RolodexTest {
	
	@Test
	void testRolodex() {
		Rolodex r = new Rolodex();
		assertEquals(r.size(), 0);
	}
	
	@Test
	void testSize() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		r.addCard("Ana", "456");
        r.addCard("Dana", "321");
		assertEquals(r.size(), 3);
	}
	
	@Test
	void testContains() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		assertTrue(r.contains("Evie"));
	}
	
	@Test
	void testAdd() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		
		Rolodex j = new Rolodex();
		
		assertNotEquals(r.toString(), j.toString());
	}

	@Test
	void testRemoveCard() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		r.addCard("Ana", "456");
		r.removeCard("Evie", "123");
		
		Rolodex j = new Rolodex();
		j.addCard("Ana", "456");
		
		assertEquals(r.toString(), j.toString());
	}
	
	@Test
	void testRemoveAllCards() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		r.addCard("Evie", "289");
		r.addCard("Ana", "456");
		r.removeAllCards("Evie");
		
		Rolodex j = new Rolodex();
		j.addCard("Ana", "456");
		
		assertEquals(r.toString(), j.toString());
	}
	
	@Test
	void testLookup() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		r.addCard("Evie", "456");
		
		ArrayList<String> testAL = new ArrayList<String>();
		testAL.add("123");
		testAL.add("456");

		
		assertEquals(r.lookup("Evie").toString(), testAL.toString());
	}
	
	@Test
	void testToString() {
		Rolodex r = new Rolodex();
		r.addCard("Evie", "123");
		r.addCard("Ana", "456");
		r.removeCard("Evie", "123");
		
		Rolodex j = new Rolodex();
		j.addCard("Ana", "456");
		
		assertEquals(r.toString(), j.toString());
	}
	
	@Test
	void testInitializeCursor() {
		Rolodex r = new Rolodex();
		r.initializeCursor();
		
		assertEquals(r.currentEntryToString(), "Separator A");
	}
	
	@Test
	void testNextSeparator() {
		Rolodex r = new Rolodex();
		r.initializeCursor();
		r.nextSeparator();
		
		assertEquals(r.currentEntryToString(), "Separator B");
	}
	
	@Test
	void testNextEntry() {
		Rolodex r = new Rolodex();
		r.addCard("John", "123");
		r.initializeCursor();
		r.nextEntry();
		
		assertEquals(r.currentEntryToString(), "Name: John, Cell: 123");
	}
	
	@Test
	void testCurrentEntryToString() {
		Rolodex r = new Rolodex();
		r.initializeCursor();
		
		assertEquals(r.currentEntryToString(), "Separator A");
	}

}