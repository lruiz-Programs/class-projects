package rolodex;

import java.util.ArrayList;

/**
 * Name: Leighana Ruiz 
 * Pledge: I pledge my honor that I have abided by the Stevens Honor System.
 */
public class Rolodex {
	private Entry cursor;
	private final Entry[] index;

	// Constructor

	Rolodex() {
	    /**
	     * constructor that creates a new Rolodex. It initializes the index data field to 25, each
	     * containing a new separator.  with a new separator. 
	     * The entry at index 0 corresponds to the letter “A”, the one in entry 1 to “B” and so on. 
	     */
		char[] bet = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
		
		index = new Entry[26];
		Entry prev = null;
		Entry curr;
		for(int i = 0; i < bet.length; i++) {
			curr = new Separator(prev, null, bet[i]);
			index[i] = curr;
			prev = curr;
		}
		index[0].prev = index[25];
		
		for(int i = bet.length - 2; i >= 0; i--) {
			index[i].next = index[i+1];
		}
		index[25].next = index[0];
		
		
	}
	/**
	 * Tests if there is a card for 'name'
	 * @param name 
	 * @throws IllegalArgumentException if the name is null.
	 * @return true / false 
	 */

	public Boolean contains(String name) {    
            if(name == null) {
                throw new IllegalArgumentException("name is null");
            }
            for(int i = 0; i < index.length; i++) {
                if(index[i].getName().equals(Character.toString(Character.toUpperCase(name.charAt(0))))){
                    Entry cur = index[i];    
                    while(!cur.next.isSeparator()){
                        if(name.equals(cur.next.getName())){
                            return true;
                        }
                        cur = cur.next;
                    }
                    return false;
                }
            }
            return false;
        }
	    
	
	/**
	 * returns the size of the rolodex
	 * @return integer
	 */
	public int size() {
		int size = 0;
	    initializeCursor();
	    while (cursor.next != index[0]) {
	        size += cursor.size();
	        nextEntry();
	    }
	    return size;

	}
	
	/**
	 * returns a list of all the numbers for 'name'
	 * @param name 
	 * @throws IllegalArgumentException if the name is not found or if it's null.
	 * @return ArrayList 
	 */
	public ArrayList<String> lookup(String name) {

		if(!contains(name)) {
			throw new IllegalArgumentException("name not found");
		}
		if(name == null) {
			throw new IllegalArgumentException("name is null");
		}
		ArrayList<String> cellList = new ArrayList<String>();
		for(int i = 0; i < index.length; i++) {
			if(index[i].getName().equals(Character.toString(Character.toUpperCase(name.charAt(0))))){
				Entry cur = index[i];
				while(!cur.next.isSeparator()){
					if(name.equals(cur.next.getName())){
						Card curCell = (Card) cur.next;
						cellList.add(curCell.getCell());
					}
					cur = cur.next;
				}
			}
		}
		return cellList;

	}

	/**
	 * define for us 
	 * returns the toString of Rolodex
	 */
	public String toString() {
		Entry current = index[0];

		StringBuilder b = new StringBuilder();
		while (current.next!=index[0]) {
			b.append(current.toString()+"\n");
			current=current.next;
		}
		b.append(current.toString()+"\n");		
		return b.toString();
	}



	/**
	 * adds a new card with name and cell info
	 * @param name 
	 * @param cell
	 * @throws IllegalArgumentException if the name is null, if the cell is null, or if there is a duplicate.
	 * no return 
	 */
	public void addCard(String name, String cell) {
		if(name == null) {
			throw new IllegalArgumentException("name is null");
		}
		if(cell == null) {
			throw new IllegalArgumentException("cell is null");
		}
		for(int i = 0; i < index.length; i++) {
			if(index[i].getName().equals(Character.toString(Character.toUpperCase(name.charAt(0))))){
				Entry cur = index[i];
				while(!cur.next.isSeparator() && (name.compareTo(cur.next.getName()) >= 0)){
					Card curCard = (Card) cur.next;
					if(name.equals(cur.next.getName()) && cell.equals(curCard.getCell())){
						throw new IllegalArgumentException("duplicate entry");						
					}
					cur = cur.next;
				}
				Entry temp = cur.next;
				cur.next = new Card(cur, temp, name, cell);
				cur.next.next.prev = cur.next;
			}
		}
	}

	
	/**
	 * removes the card with name and cell info 
	 * @param name
	 * @param cell 
	 * @throws IllegalArgumentException if the name is null, card is null or the name does not exist.
	 * no return 
	 */
	public void removeCard(String name, String cell) {
		if(name == null) {
			throw new IllegalArgumentException("name is null");
		}
		if(cell == null) {
			throw new IllegalArgumentException("cell is null");
		}
		if(!contains(name)) {
			throw new IllegalArgumentException("name does not exist");
		}
		for(int i = 0; i < index.length; i++) {
			if(index[i].getName().equals(Character.toString(Character.toUpperCase(name.charAt(0))))){
				Entry cur = index[i];
				while(!cur.next.isSeparator()){
					if(name.equals(cur.next.getName())){
						Card curCard = (Card) cur.next;
						if(cell.equals(curCard.getCell())) {
							cur.next.next.prev = cur.next.prev;
							cur.next = cur.next.next;
							break;
						}
					}
					cur = cur.next;
				}
			}
		}
	}
	
	/**
	 * removes all the cards with the 'name'
	 * @param name 
	 * @throws IllegalArgumentException if the name is null, or does not exist
	 * no return 
	 */
	public void removeAllCards(String name) {
		if(name == null) {
			throw new IllegalArgumentException("name is null");
		}
		if(!contains(name)){
			throw new IllegalArgumentException("name does not exist");
		}
		for(int i = 0; i < index.length; i++) {
			if(index[i].getName().equals(Character.toString(Character.toUpperCase(name.charAt(0))))){
				Entry cur = index[i];
				while(!cur.next.isSeparator()){
					if(name.equals(cur.next.getName())){
							cur.next.next.prev = cur.next.prev;
							cur.next = cur.next.next;
						}
					else {
					cur = cur.next;
					}
					}
				}
			}
		}

	// Cursor operations
	
	/**
	 * initalizes the cursor 
	 */
	public void initializeCursor() {
		    cursor = index[0];

	}

	/**
	 * moves the cursor to the next 
	 */
	public void nextSeparator() {
		    while(!cursor.next.isSeparator()) {
		    	cursor = cursor.next;
		    }

	}

	/**
	 * moves the cursor to the next entry 
	 */
	public void nextEntry() {
		    cursor = cursor.next;

	}

	/**
	 * returns the string representation of the current entry of the cursor 
	 */
	public String currentEntryToString() {
		return cursor.toString();
	}

	


	public static void main(String[] args) {

		Rolodex r = new Rolodex();


		System.out.println(r);

		r.addCard("Chloe", "123");
		r.addCard("Chad", "23");
		r.addCard("Cris", "3");
		r.addCard("Cris", "4");
		r.addCard("Cris", "5");
		//		r.addCard("Cris", "4");
		r.addCard("Maddie", "23");

		System.out.println(r);

		System.out.println(r.contains("Albert"));

		r.removeAllCards("Cris");

		System.out.println(r);

		r.removeAllCards("Chad");
		r.removeAllCards("Chloe");

		r.addCard("Chloe", "123");
		r.addCard("Chad", "23");
		r.addCard("Cris", "3");
		r.addCard("Cris", "4");

		System.out.println(r);




	}

}
